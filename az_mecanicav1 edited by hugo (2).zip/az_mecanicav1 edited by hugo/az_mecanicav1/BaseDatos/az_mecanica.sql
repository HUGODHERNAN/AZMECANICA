-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-11-2025 a las 13:10:51
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `az_mecanica`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cita`
--

CREATE TABLE `cita` (
  `id_cita` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `dni_cliente` varchar(15) NOT NULL,
  `placa_vehiculo` varchar(10) NOT NULL,
  `id_servicio` int(11) NOT NULL,
  `dni_empleado` varchar(15) NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'PENDIENTE',
  `notas` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cita`
--

INSERT INTO `cita` (`id_cita`, `fecha`, `hora`, `dni_cliente`, `placa_vehiculo`, `id_servicio`, `dni_empleado`, `estado`, `notas`) VALUES
(1, '2025-11-22', '08:45:00', '65432109', 'KDC-401', 1, '73212188', 'CANCELADA', 'cambio de aciete debe'),
(2, '2025-11-21', '07:06:00', '10452367', 'KDC-401', 4, '12345675', 'CANCELADA', 'cambio pagado'),
(3, '2025-11-21', '07:17:00', '65432109', 'KLD-502', 2, '12345672', 'CANCELADA', 'basico'),
(4, '2025-11-23', '07:27:00', '87654321', 'KLD-502', 1, '73212105', 'CONFIRMADA', 'meacnico pagado'),
(8, '2025-11-28', '19:42:00', '10452367', 'KLD-502', 1, '12345672', 'CANCELADA', 'asdasdasd'),
(10, '2025-11-27', '19:49:00', '10452367', 'MFE-603', 1, '12345678', 'CANCELADA', '12345678'),
(11, '2025-11-27', '19:06:00', '65432109', 'JBN-444', 2, '12345678', 'CONFIRMADA', '123123123123123123'),
(12, '2025-11-27', '19:20:00', '10452367', 'KLD-502', 1, '12345678', 'CONFIRMADA', 'asdf1234'),
(13, '2025-11-28', '19:59:00', '65432109', 'JBN-444', 4, '12345672', 'CANCELADA', 'preuba que cansa'),
(14, '2025-11-28', '20:07:00', '65432109', 'JBN-444', 2, '73212105', 'CANCELADA', 'pruebaaaa'),
(15, '2025-11-29', '23:26:00', '10452367', 'KLD-502', 4, '12345675', 'CONFIRMADA', 'jose ara las pruebas'),
(16, '2025-11-29', '17:32:00', '65432109', 'JBN-444', 1, '12345675', 'CANCELADA', 'josemenca'),
(17, '2025-11-29', '20:42:00', '10452367', 'KLD-502', 4, '73212188', 'CONFIRMADA', 'carlos ara esto'),
(18, '2025-11-30', '11:06:00', '10452367', 'MFE-603', 1, '73212188', 'PENDIENTE', 'preubaso'),
(19, '2025-11-30', '06:15:00', '87654321', 'lDC-401', 1, '12345672', 'CANCELADA', ''),
(21, '2025-11-05', '03:08:00', '65432109', 'JBN-444', 1, '73212188', 'PENDIENTE', ''),
(22, '2025-12-05', '05:20:00', '65432109', 'aaaaaaa', 2, '73212188', 'PENDIENTE', ''),
(23, '2025-11-23', '11:10:00', '65432109', 'aaaaaa', 5, '12345678', 'PENDIENTE', ''),
(24, '2025-11-01', '07:11:00', '65432109', 'aaaaaa', 5, '73212188', 'CANCELADA', ''),
(25, '2025-07-07', '09:47:00', '65432109', '123-avv', 5, '12345678', 'PENDIENTE', 'pruebaaaaa de hugooo'),
(26, '2025-12-31', '09:50:00', '74691946', 'JHN-202', 6, '12345678', 'PENDIENTE', 'prueba dehugo2222'),
(27, '2025-03-01', '14:10:00', '10987654', 'ABC-J34', 1, '12345678', 'PENDIENTE', 'prueba333');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `dni` varchar(15) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`dni`, `nombres`, `apellidos`, `telefono`, `correo`, `direccion`) VALUES
('10452367', 'Carlos Alberto', 'Soto Perezssss', '987654321', 'carlos.soto@ejemplo.com', ''),
('10987654', 'Hernan', 'Soto', '970987654', 'hernan@email.com', ''),
('45678901', 'Luis', 'Cáceres', '970654321', 'luis@email.com', ''),
('55555555', 'Mariaa', 'Bertanco', '666666666', 'berta@asd.com', 'barrio nose'),
('65432109', 'Ben10', 'Canela', '970111222', 'ben@email.com', 'av . surita 123'),
('74691946', 'jhon', 'velasquez', '9999999999', 'jhonn@gmail.com', 'calle jhon'),
('77777777', 'Malcom', 'Rojas', '888888888', 'malcom@miranda.com', 'av. Never Land 111'),
('87654321', 'Tyler', 'Joseph', '970123456', 'tyler@email.com', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `dni` varchar(15) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fecha_contratacion` date DEFAULT NULL,
  `cargo` varchar(50) DEFAULT NULL,
  `salario` decimal(10,2) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`dni`, `nombres`, `apellidos`, `telefono`, `email`, `fecha_contratacion`, `cargo`, `salario`, `estado`) VALUES
('12345672', 'Josefina', 'Carlo2', '999888777', 'jose@az21.com', '2025-11-21', 'Mecánico', 3000.00, 1),
('12345675', 'Jose', 'Carlo', '999888777', 'jose@az2.com', '2025-11-21', 'Mecánico', 3000.00, 1),
('12345678', 'Admin122', 'Sistema', '999888777', 'admin@az.com', '2025-11-21', 'Administrador', 3000.00, 1),
('73212105', 'Mecanico2', 'Sistema', '999888777', 'admin@aze1.com', '2025-11-21', 'Mecánico', 3000.00, 1),
('73212108', 'carlos', 'Carlo', '999888777', 'calos@az2.com', '2025-11-21', 'Mecánico', 3000.00, 0),
('73212109', 'Mecanico', 'Sistema', '999888777', 'admin@aze.com', '2025-11-21', 'Mecánico', 3000.00, 0),
('73212188', 'carlos', 'Carlo', '999888777', 'calos@az111.com', '2025-11-21', 'Mecánico', 3000.00, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `cod_producto` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `cant_inicial` int(11) NOT NULL DEFAULT 0,
  `costo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `id_proveedor` varchar(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`cod_producto`, `nombre`, `categoria`, `cant_inicial`, `costo`, `id_proveedor`) VALUES
(1, 'Prueba', 'desert', 20, 12.00, '12345698721'),
(2, 'Filtro de Aire Motor', 'Filtros', 4, 35.00, '12345698721'),
(3, 'BaterÃ­a 13 Placas 12V', 'ElÃ©ctrico', 2, 280.00, '12345698721'),
(4, 'Rodaje de Rueda', 'SuspensiÃ³n', 20, 75.00, '12345698721');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proforma`
--

CREATE TABLE `proforma` (
  `id_proforma` varchar(15) NOT NULL,
  `fecha` date NOT NULL DEFAULT curdate(),
  `id_cliente` varchar(15) NOT NULL,
  `monto_estimado` decimal(10,2) NOT NULL,
  `estado` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proforma`
--

INSERT INTO `proforma` (`id_proforma`, `fecha`, `id_cliente`, `monto_estimado`, `estado`) VALUES
('PF-001', '2025-11-27', '10452367', 1000.00, 'ACEPTADA'),
('PF-002', '2025-11-27', '45678901', 1000.00, 'PENDIENTE'),
('PF-003', '2025-11-28', '65432109', 3000.00, 'ACEPTADA'),
('PF001', '2025-11-27', '65432109', 1000.00, 'PENDIENTE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `ruc` varchar(13) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`ruc`, `nombre`, `telefono`, `email`, `direccion`) VALUES
('12345698721', 'Prueb111', '987654321', 'prueba@hmail.com', 'av parra 12333'),
('20746919455', 'panzonesSAC', '907049253', 'chambitas@gmail.com', 'calle obrera');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `id_servicio` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `tiempo_estimado` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`id_servicio`, `nombre`, `categoria`, `descripcion`, `precio`, `tiempo_estimado`) VALUES
(1, 'Cambio de Aceite Estandar', 'Mantenimiento', 'Incluye cambio de aceite, filtro de aceite y revision de 21 puntos.', 85.50, '1 hora'),
(2, 'Diagnóstico Electrónico Básico', 'Diagnóstico', 'Escaneo de códigos de error (DTC) y reporte preliminar del sistema electrónico.', 30.00, '30 minutos'),
(4, 'Cambio de Aceite Estandar', '', 'cambio de aceite', 85.50, '1 hora'),
(5, 'Afinamiento de Motor', 'Mantenimiento', 'Limpieza de inyectores, cambio de bujÃ­as y filtros de aire/combustible.', 250.00, '3 horas'),
(6, 'Cambio de Aceite y Filtro', 'Mantenimiento', 'Cambio de aceite de motor sintÃ©tico y reemplazo de filtro de aceite.', 80.00, '45 min');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `dni` char(8) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `rol` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`dni`, `contraseña`, `nombre`, `apellido`, `telefono`, `email`, `direccion`, `rol`) VALUES
('12345678', 'f0c19f5da6c8d1e2bb5b92e2370dff5efe2a457ee379029086e25a487bcd49ea', 'Admin', 'Sistema', '987654321', 'admin@mecanicaaz.com', 'Calle Principal #1', 'ADMIN'),
('74691945', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Hugo Hernan', 'Huallpa Velasquez', '907049253', 'u21310779@utp.edu.pe', 'calle obrera', 'ADMIN'),
('74747474', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Hugo2', 'velasquez', '956595659', 'hugg@utp.edu.pe', 'calle obrera', 'USER'),
('87654321', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'prueba1', 'perez', '987654333', 'jose@meca.com', 'av. jose perez 123', 'ADMIN'),
('admin', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 'az_mecanica', 'jimenez', '456789087', 'redrithaz@gmail.com', 'AV. ARGENTINA NRO. 4793 URB. PARQUE INDUSTRIAL', 'USER');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `placa` varchar(10) NOT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `modelo` varchar(50) DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  `color` varchar(30) DEFAULT NULL,
  `combustible` varchar(30) DEFAULT NULL,
  `transmision` varchar(20) DEFAULT NULL,
  `num_motor` varchar(50) DEFAULT NULL,
  `vin` varchar(17) DEFAULT NULL,
  `kilometraje` int(11) DEFAULT NULL,
  `soat` varchar(30) DEFAULT NULL,
  `tarjeta_propietario` varchar(50) DEFAULT NULL,
  `dni_cliente` char(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vehiculo`
--

INSERT INTO `vehiculo` (`placa`, `marca`, `tipo`, `modelo`, `anio`, `color`, `combustible`, `transmision`, `num_motor`, `vin`, `kilometraje`, `soat`, `tarjeta_propietario`, `dni_cliente`) VALUES
('123-avv', 'Toyota', 'Pick-up', 'Hilux', 2023, '', 'Gasolina', '', 'v-1123', '121212', NULL, NULL, NULL, '65432109'),
('aaaaaa', 'Toyota', 'SUV', 'Rush', NULL, 'Verde', 'GNV', 'AutomÃ¡tica', 'bbbbbbbbbb', 'bbbbbbbbbbbbbb', NULL, NULL, NULL, '65432109'),
('aaaaaaa', 'Honda', 'SedÃ¡n', 'Civic', 2020, 'Blanco', 'Gasolina', 'AutomÃ¡tica', 'aaaaaa', 'aaaaaaa', NULL, NULL, NULL, '65432109'),
('aasdasd', 'asdasd', 'SedÃ¡n', 'asdasd', 1970, 'asdasdasd', 'GNV', 'AutomÃ¡tica', 'asdasd', 'asdasd', NULL, NULL, NULL, '65432109'),
('abc-111', 'Toyota', 'SedÃ¡n', 'Corolla', 2022, 'Naranja', 'Gasolina', 'AutomÃ¡tica', 'v-1123', '1234555', NULL, NULL, NULL, '77777777'),
('ABC-J34', 'Toyota', 'Pick-up', 'RAV4', 2022, 'rojo', 'Gasolina', 'AutomÃ¡tica', 'v-1123', '12434645', NULL, NULL, NULL, '10987654'),
('JBN-444', 'HondAAA', 'SUV', 'R43', 2020, 'azul', 'GNV', 'AutomÃ¡tica', 'v10', '1234', NULL, NULL, NULL, '65432109'),
('JDC-401', 'HondAAA', 'Van', 'R43', 2020, 'azul', 'Gasolina', 'CVT', 'v10', '1234', NULL, NULL, NULL, '10987654'),
('JHN-202', 'Ford', 'SUV', 'Explorer', 2023, 'Naranja', 'GNV', 'MecÃ¡nica', 'v-1123', '121212', NULL, NULL, NULL, '74691946'),
('KDC-401', 'Hondxx', 'SUV', 'CAS', 2020, 'azul', 'GLP', 'CVT', NULL, '1234', NULL, NULL, NULL, '10452367'),
('KLD-502', 'Nissan', 'Hatchback', 'March', 2018, 'Blanco', 'Gasolina', 'CVT', NULL, '', NULL, NULL, NULL, '10452367'),
('lDC-401', 'Hondxx', 'SUV', 'CAS', 2020, 'azul', 'GNV', NULL, NULL, NULL, NULL, NULL, NULL, '87654321'),
('malcom', 'Toyota', 'SedÃ¡n', 'Yaris', 2022, 'MarrÃ³n', 'GNV', 'AutomÃ¡tica', 'bbbbbbbbbb', 'bbbbbbbbbbbbbb', NULL, NULL, NULL, '77777777'),
('MFE-603', 'Mitsubishi', 'SUV', 'ASX', 2022, 'Rojo', 'Diesel', NULL, '4N146030', NULL, 12500, 'SOAT-MITS-22', 'TP-ASX-603', '10452367');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cita`
--
ALTER TABLE `cita`
  ADD PRIMARY KEY (`id_cita`),
  ADD UNIQUE KEY `uq_cita_recurso_tiempo` (`placa_vehiculo`,`fecha`,`hora`),
  ADD UNIQUE KEY `uq_cita_empleado_tiempo` (`dni_empleado`,`fecha`,`hora`),
  ADD KEY `fk_cita_cliente` (`dni_cliente`),
  ADD KEY `fk_cita_servicio` (`id_servicio`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`dni`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`dni`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`cod_producto`),
  ADD KEY `fk_producto_proveedor` (`id_proveedor`);

--
-- Indices de la tabla `proforma`
--
ALTER TABLE `proforma`
  ADD PRIMARY KEY (`id_proforma`),
  ADD KEY `fk_proforma_cliente` (`id_cliente`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`ruc`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`id_servicio`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`dni`),
  ADD UNIQUE KEY `uq_usuario_email` (`email`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`placa`),
  ADD KEY `fk_vehiculo_cliente` (`dni_cliente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cita`
--
ALTER TABLE `cita`
  MODIFY `id_cita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `cod_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `servicio`
--
ALTER TABLE `servicio`
  MODIFY `id_servicio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cita`
--
ALTER TABLE `cita`
  ADD CONSTRAINT `fk_cita_cliente` FOREIGN KEY (`dni_cliente`) REFERENCES `clientes` (`dni`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cita_empleado` FOREIGN KEY (`dni_empleado`) REFERENCES `empleados` (`dni`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cita_servicio` FOREIGN KEY (`id_servicio`) REFERENCES `servicio` (`id_servicio`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cita_vehiculo` FOREIGN KEY (`placa_vehiculo`) REFERENCES `vehiculo` (`placa`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `fk_producto_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`ruc`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `proforma`
--
ALTER TABLE `proforma`
  ADD CONSTRAINT `fk_proforma_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`dni`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD CONSTRAINT `fk_vehiculo_cliente` FOREIGN KEY (`dni_cliente`) REFERENCES `clientes` (`dni`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
